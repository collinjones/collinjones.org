This is our project called Recip-ez, it is a website for people to use ingredients in their fridge as search criteria to find recipes that match those ingredient. We also integrated a way for users to add their own favorite recipes to the website.  

Heroku website: https://recip-ez.herokuapp.com/index.php

The orginization of our project is all the webpages are in the views folder. Inside the views folder is an actions folder, which include php scripts that are run for different pages. The templates folder just includes a template of one of our pages, to easily create new pages if we need to. The resources folder includes two subfolders, one includes the css folder which holds the website's css. The other is our js folder which is used for our password checking.

To run our website locally, you first need a program to run php for you (in our case we used XAMPP). After downloading XAMPP you start the php server, with all the website files in the htdocs folder. You then navigate to "localhost/recip-ez/index.php" to see the website.
